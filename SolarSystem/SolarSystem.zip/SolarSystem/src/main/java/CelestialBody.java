public class CelestialBody {
    private String name;
    private double mass;
    private double radius;
    private Vector3D position;
    private Vector3D velocity;
    private String textureFilename;

    public CelestialBody(String name, double mass, double radius, Vector3D position, Vector3D velocity, String textureFilename) {
        this.name = name;
        this.mass = mass;
        this.radius = radius;
        this.position = position;
        this.velocity = velocity;
        this.textureFilename = textureFilename;
    }

    public String getName() {
        return name;
    }

    public double getMass() {
        return mass;
    }

    public double getRadius() {
        return radius;
    }

    public Vector3D getPosition() {
        return position;
    }

    public Vector3D getVelocity() {
        return velocity;
    }

    public void setVelocity(Vector3D velocity) {
        this.velocity = velocity;
    }

    public void setPosition(Vector3D position) {
        this.position = position;
    }
    public String getTextureFilename() {
        return textureFilename;
    }
    public void setRadius(double radius) {
        this.radius = radius;
    }
}
