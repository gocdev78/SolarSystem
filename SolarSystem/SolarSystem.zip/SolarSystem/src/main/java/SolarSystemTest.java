import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class SolarSystemTest {
    @Test
    public void testSolarSystemInitialization() {
        SolarSystem solarSystem = new SolarSystem();
        Vector3D position = new Vector3D(1, 2, 3);
        Vector3D velocity = new Vector3D(4, 5, 6);
        CelestialBody body = new CelestialBody("Earth", 5.972 * Math.pow(10, 24), 6371, position, velocity, "earth.jpg");

        solarSystem.addBody(body);

        assertEquals(1, solarSystem.getBodies().size());
        assertEquals(body, solarSystem.getBodies().get(0));
    }
}
