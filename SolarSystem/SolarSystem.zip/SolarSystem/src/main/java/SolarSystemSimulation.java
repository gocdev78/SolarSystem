import javafx.animation.AnimationTimer;
import javafx.scene.Group;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Sphere;
import java.io.InputStream;
import javafx.scene.image.Image;
import java.util.Map;
import java.util.HashMap;

public class SolarSystemSimulation extends Group {
    private SolarSystem solarSystem;
    private Map<CelestialBody, Sphere> spheres;

    public SolarSystemSimulation(SolarSystem solarSystem) {
        this.solarSystem = solarSystem;
        this.spheres = new HashMap<>();

        for (CelestialBody body : solarSystem.getBodies()) {
            Sphere sphere = new Sphere(body.getRadius());
            PhongMaterial material = new PhongMaterial();
            Image texture = loadImage(body.getTextureFilename());
            if (texture != null) {
                material.setDiffuseMap(texture);
            }
            sphere.setMaterial(material);
            spheres.put(body, sphere);
            getChildren().add(sphere);
        }

        // Wypisanie promieni sfer
        for (CelestialBody body : solarSystem.getBodies()) {
            Sphere sphere = spheres.get(body);
            System.out.println("Promień " + body.getName() + ": " + sphere.getRadius());
        }
    }

    public void setRadius(CelestialBody body, double radius) {
        Sphere sphere = spheres.get(body);
        if (sphere != null) {
            sphere.setRadius(radius);
        }
    }

    private Image loadImage(String filename) {
        InputStream inputStream = getClass().getResourceAsStream("/" + filename);
        return new Image(inputStream);
    }

    public void updatePositions(double deltaTime) {
        for (CelestialBody body : solarSystem.getBodies()) {
            Vector3D currentPosition = body.getPosition();
            Vector3D velocity = body.getVelocity();
            Vector3D newPosition = currentPosition.add(velocity.scale(deltaTime));
            body.setPosition(newPosition);
        }
    }

    public void start() {

    }

    private Vector3D calculateGravitationalAcceleration(CelestialBody body) {
        Vector3D acceleration = new Vector3D(0, 0, 0);
        for (CelestialBody otherBody : solarSystem.getBodies()) {
            if (body != otherBody) {
                // Obliczamy wektor odległości między ciałami
                Vector3D distance = otherBody.getPosition().subtract(body.getPosition());

                // Obliczamy siłę grawitacyjną między ciałami
                double gravitationalForce = calculateGravitationalForce(body, otherBody, distance.magnitude());

                // Obliczamy wektor przyspieszenia na podstawie siły i odległości
                Vector3D bodyAcceleration = distance.scale(gravitationalForce / body.getMass());

                // Dodajemy przyspieszenie od innego ciała do ogólnego przyspieszenia
                acceleration = acceleration.add(bodyAcceleration);
            }
        }
        return acceleration;
    }

    private double calculateGravitationalForce(CelestialBody body1, CelestialBody body2, double distance) {
        final double gravitationalConstant = 6.67430e-11;
        return gravitationalConstant * (body1.getMass() * body2.getMass()) / (distance * distance);
    }
}
