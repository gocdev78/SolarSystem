import javafx.application.Application;
import javafx.scene.PerspectiveCamera;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class MainApp extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        SolarSystem solarSystem = initSolarSystem();
        SolarSystemSimulation simulation = new SolarSystemSimulation(solarSystem);

        Scene scene = new Scene(simulation, 1200, 900);
        scene.setFill(javafx.scene.paint.Color.BLACK);

        PerspectiveCamera camera = new PerspectiveCamera();
        camera.setTranslateZ(-6000000); // Przesunięcie kamery wzdłuż osi Z
        camera.setFarClip(20000); // Odległość renderowania obiektów
        scene.setCamera(camera);

        stage.setScene(scene);
        stage.show();

        simulation.start();

        // Ustawienie większego promienia dla słońca
        CelestialBody sun = solarSystem.getBodies().get(0);
        sun.setRadius(1000);
    }

    private SolarSystem initSolarSystem() {
        SolarSystem solarSystem = new SolarSystem();

        // Ustalamy rozmiary ciał niebieskich
        double sunRadius = 696340;  // Promień Słońca w km
        double earthRadius = sunRadius / 8;  // Ziemia ma 1/8 promienia Słońca

        // Ustalamy odległości ciał niebieskich
        double sunEarthDistance = 8 * 2 * earthRadius;  // Ziemia jest oddalona od Słońca o 8 średnic Ziemi

        CelestialBody sun = new CelestialBody("Sun", 1.989 * Math.pow(10, 30), sunRadius, new Vector3D(0, 0, 0), new Vector3D(0, 0, 0), "sun.jpg");
        solarSystem.addBody(sun);

        // Ustalamy prędkość początkową Ziemi
        Vector3D earthVelocity = new Vector3D(0, 30 * 1000, 0);  // 30 km/s to średnia prędkość orbitalna Ziemi
        CelestialBody earth = new CelestialBody("Earth", 5.972 * Math.pow(10, 24), earthRadius, new Vector3D(sunEarthDistance, 0, 0), earthVelocity, "earth.jpg");
        solarSystem.addBody(earth);

        // ... dodajemy resztę ciał niebieskich, dla których mamy tekstury


        return solarSystem;
    }

    public static void main(String[] args) {
        launch(args);
    }
}